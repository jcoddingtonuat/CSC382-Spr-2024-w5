﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Graphing
{
    public class Node
    {
        public string Name { get; set; }

        public Node() { }

        /// <summary>
        /// Add a node.
        /// </summary>
        /// <param name="name">The node's name.</param>
        public Node(string name)
        {
            Name = name;
        }
    }
}
