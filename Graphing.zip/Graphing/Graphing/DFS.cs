﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Graphing
{
    class DFS
    {
        private Node startNode;
        private Node endNode;
        private Graph graph;

        private List<Node> path = new List<Node>();
        private List<Node> visited = new List<Node>();

        /// <summary>
        /// Depth first search constructor.
        /// </summary>
        /// <param name="start">Starting node.</param>
        /// <param name="end">Target Node.</param>
        /// <param name="graph">The graph.</param>
        public DFS(Node start, Node end, Graph graph)
        {
            startNode = start;
            endNode = end;
            this.graph = graph;
        }

        /// <summary>
        /// Run the depth first search.
        /// </summary>
        /// <returns>The path if it exists, an error message otherwise.</returns>
        public string Run()
        {
            StringBuilder resultsMessage = new StringBuilder();

            resultsMessage.AppendLine($"\nDepth First Search: {startNode.Name} -> {endNode.Name}");

            //the path is found return the path.
            if (SearchNodes(startNode))
            {
                //reverse the path, nodes were added in reverse order.
                path.Reverse();

                foreach (var node in path)
                {
                    resultsMessage.Append($"{node.Name}");
                    if (node != path.Last())
                        resultsMessage.Append(" -> ");
                }
            }
            else
            {
                //the path was not found.
                resultsMessage.Append("No path exists");
                
            }

            return resultsMessage.ToString();
        }

        /// <summary>
        /// Perform a depth first search of the nodes.
        /// </summary>
        /// <param name="current">The node to be checked.</param>
        /// <returns>True if the target has been found, false otherwise.</returns>
        private bool SearchNodes(Node current)
        {
            //add this node to the visited list.
            visited.Add(current);

            //if this node is the target, add it to the path list and return.
            if (current == endNode)
            {
                path.Add(current);
                return true;
            }

            //get the neighboring nodes that have not been visited.
            List<Node> nodeNeighbors = graph.Arcs.Where(a => a.A == current && !visited.Contains(a.B)).Select(a => a.B).ToList();

            //if the node has neighbors.
            if (nodeNeighbors != null)
            {
                //conduct the search down each neighbor.
                foreach (var node in nodeNeighbors)
                {
                    //the node has been found, add this node to the path list and return true.
                    if (SearchNodes(node))
                    {
                        path.Add(current);
                        return true;
                    }
                }
            }

            //the target node was not found, return false.
            return false;
        }
    }
}
