﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Graphing
{
    class Arc
    {
        public string Name { get; set; }
        public Node A { get; private set; }
        public Node B { get; private set; }
        public bool IsDirected { get; private set; }
        public float Distance { get; private set; }

        /// <summary>
        /// Add an arc.
        /// </summary>
        /// <param name="a">First node.</param>
        /// <param name="b">Second node.</param>
        /// <param name="isDirected">Optional. Default is false, if the node is directed, it is a->b</param>
        /// <param name="distance">Optional. The arc's distance.</param>
        /// <param name="name">Optional. The arc's name.</param>
        public Arc(Node a, Node b, bool isDirected = false, float distance = 1.0f, string name = null)
        {
            if (a == null || b == null || a == b)
                return;

            Name = name;
            A = a;
            B = b;
            Distance = distance;
            IsDirected = isDirected;
        }
    }
}
