﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Graphing
{
    class Dijkstra
    {
        public List<Node> Path { get; private set; } = new List<Node>();

        private List<Mark> unvisited = new List<Mark>();
        private List<Mark> visited = new List<Mark>();

        private Mark startMark;
        private Node endNode;

        /// <summary>
        /// Used to mark the nodes in the graph.
        /// </summary>
        private class Mark
        {
            public Node Node;
            public float Distance = float.PositiveInfinity;
            public List<Arc> Arcs;
            public Mark Previous;

            /// <summary>
            /// Mark constructor.
            /// </summary>
            /// <param name="node">This node.</param>
            /// <param name="arcs">This node's arcs where this node is the origination.</param>
            public Mark(Node node, List<Arc> arcs)
            {
                Node = node;
                Arcs = arcs;
            }
        }

        /// <summary>
        /// Dijkstra's Algorithm.
        /// </summary>
        /// <param name="start">Start node.</param>
        /// <param name="end">End node.</param>
        /// <param name="graph">The Graph.</param>
        public Dijkstra(Node start, Node end, Graph graph)
        {
            //convert all nodes to marks.
            foreach (Node node in graph.Nodes)
            {
                unvisited.Add(new Mark(node, graph.Arcs.Where(a => a.A == node).ToList()));
            }

            //set the start mark and distance to zero.
            startMark = unvisited.Find(m => m.Node == start);
            startMark.Distance = 0f;

            //set the endNode.
            endNode = end;
        }

        /// <summary>
        /// Visit the marks and see if the end is found.
        /// </summary>
        /// <param name="current">Current mark.</param>
        /// <param name="end">End node.</param>
        /// <returns></returns>
        private bool VisitMarksEndFound(Mark current, Node end)
        {
            //loops through this mark's arcs.
            foreach (var arc in current.Arcs)
            {
                //find this mark's neighbor.
                Mark neighbor = unvisited.Find(m => m.Node == arc.B);

                //if this mark has neighbors and their distance is greater than this mark plus the arc distance.
                if (neighbor != null && neighbor.Distance > current.Distance + arc.Distance)
                {
                    //set the neighbors distance.
                    neighbor.Distance = current.Distance + arc.Distance;
                    //if the neighbor's previous mark is null or the previous distance is greater than this node and the arc distance.
                    if (neighbor.Previous == null || neighbor.Previous.Distance > current.Distance + arc.Distance)
                        //set neighbor's previous to this mark.
                        neighbor.Previous = current;
                }
            }

            //add the current mark to the visited list and remove it from the unvisited list.
            visited.Add(current);
            unvisited.Remove(current);

            //if visited list contains the end point, return true, the path is possible.
            if (visited.Find(m => m.Node == end) != null)
                return true;
            //if all remaining unvisited marks are infinity, they are not connected, the path is not possible.
            else if (unvisited.Min(m => m.Distance) == float.PositiveInfinity)
                return false;
            else
            {
                //visit the next mark with the least distance.
                Mark next = unvisited.Find(m => m.Distance == unvisited.Min(m => m.Distance));
                return VisitMarksEndFound(next, end);
            }
        }

        /// <summary>
        /// Construct the path.
        /// </summary>
        /// <param name="start">Start node.</param>
        /// <param name="current">Current mark.</param>
        private void MakePath(Node start, Mark current)
        {
            //add the current node to the path.
            Path.Add(current.Node);

            //Start node not found, call the function recursively.
            if (current.Node != start)
                MakePath(start, current.Previous);
            //Start node is found, reverse the path.
            else
                Path.Reverse();
        }

        /// <summary>
        /// Run the algorithm.
        /// </summary>
        /// <returns>The message with the path if successfull, error message otherwise.</returns>
        public string Run()
        {
            //build the result message
            StringBuilder resultsMessage = new StringBuilder();

            resultsMessage.AppendLine($"\nDijkstra's Algorithm: {startMark.Node.Name} -> {endNode.Name}");

            //if this is false, no path is possible, return with error message.
            if (!VisitMarksEndFound(startMark, endNode))
            {
                resultsMessage.Append("No path exists.");
            }
            else
            {
                //the path is possible, make it.
                MakePath(startMark.Node, visited.Last());

                foreach (var node in Path)
                {
                    resultsMessage.Append($"{node.Name}");
                    if (node != Path.Last())
                        resultsMessage.Append(" -> ");
                }
            }

            return resultsMessage.ToString();
        }
    }
}
