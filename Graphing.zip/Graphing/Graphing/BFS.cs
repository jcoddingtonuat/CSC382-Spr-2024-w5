﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Graphing
{
    class BFS
    {
        private Node startNode;
        private Node endNode;
        private Graph graph;

        private Queue<Node> searchQueue = new Queue<Node>();
        private List<Node> visited = new List<Node>();
        private List<Node> path = new List<Node>();

        /// <summary>
        /// Breadth first search algorithm.
        /// </summary>
        /// <param name="start">Starting node.</param>
        /// <param name="end">Target node.</param>
        /// <param name="graph">The graph.</param>
        public BFS(Node start, Node end, Graph graph)
        {
            startNode = start;
            endNode = end;
            this.graph = graph;
        }

        public string Run()
        {
            //add the starting node to the queue and mark it as visited.
            searchQueue.Enqueue(startNode);
            visited.Add(startNode);

            StringBuilder resultsMessage = new StringBuilder();

            resultsMessage.AppendLine($"\nBreadth First Search: {startNode.Name} -> {endNode.Name}");

            //run the search, target was successfull found.
            if (SearchNodes())
            {
                BuildPath(endNode);

                foreach (var node in path)
                {
                    resultsMessage.Append($"{node.Name}");
                    if (node != path.Last())
                        resultsMessage.Append(" -> ");
                }
            }
            else
            {
                //target was not found.
                resultsMessage.Append("No path exists.");
            }

            return resultsMessage.ToString();
        }

        /// <summary>
        /// Searches the node.
        /// </summary>
        /// <returns>True if there is a path, false otherwise.</returns>
        private bool SearchNodes()
        {
            //remove the first node from the queue
            Node current = searchQueue.Dequeue();

            //the node is found, add it to the path and return.
            if (current == endNode)
            {
                path.Add(current);
                return true;
            }

            //find current node's neighbors.
            List<Node> nodeNeighbors = graph.Arcs.Where(a => a.A == current && !visited.Contains(a.B)).Select(a => a.B).ToList();

            //add each of them to the queue and mark them as visited.
            foreach (var node in nodeNeighbors)
            {
                visited.Add(node);
                searchQueue.Enqueue(node);
            }

            //if the queue is not empty and search nodes comes back true, return true.
            if (searchQueue.Count > 0 && SearchNodes())
                return true;

            //the path is not possible.
            return false;
        }

        /// <summary>
        /// Build the path.
        /// </summary>
        /// <param name="current">Current node to build back from.</param>
        private void BuildPath(Node current)
        {
            //we made it back to the startnode, reverse the path and return.
            if (current == startNode)
            {
                path.Reverse();
                return;
            }

            //find the predecessor node.
            Node predecessor = graph.Arcs.First(a => a.B == current && visited.Contains(a.A)).A;

            //add it to the path and keep going.
            path.Add(predecessor);
            BuildPath(predecessor);
        }
    }
}
