﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Graphing
{
    class Graph
    {
        public List<Node> Nodes { get; private set; } = new List<Node>();
        public List<Arc> Arcs { get; private set; } = new List<Arc>();

        /// <summary>
        /// Add a node.
        /// </summary>
        /// <param name="name">Optional node name.</param>
        /// <returns>The added node.</returns>
        public Node AddNode(string name = null)
        {
            Node newNode = new Node(name);
            Nodes.Add(newNode);
            return Nodes.Find(n => n.Equals(newNode));
        }

        /// <summary>
        /// Add an arc.
        /// </summary>
        /// <param name="a">Arc starting point.</param>
        /// <param name="b">Arc ending point.</param>
        /// <param name="isDirected">If the arc is directed, a->b. Default is false.</param>
        /// <param name="distance">Optional distance value. Default is 1.</param>
        /// <param name="name">Optional arc name. Default is null.</param>
        /// <returns>The added arc.</returns>
        public Arc AddArc(Node a, Node b, bool isDirected = false, float distance = 1f, string name = null)
        {
            Arc newArc = new Arc(a, b, isDirected, distance, name);
            Arcs.Add(newArc);
            return Arcs.Find(arc => arc.Equals(newArc));
        }
    }
}
