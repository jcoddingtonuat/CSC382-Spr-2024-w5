﻿using System;

namespace Graphing
{
    class Program
    {
        static void Main(string[] args)
        {
            Graph graph = new Graph();

            Node a = graph.AddNode("A");
            Node b = graph.AddNode("B");
            Node c = graph.AddNode("C");
            Node d = graph.AddNode("D");
            Node e = graph.AddNode("E");

            Node f = graph.AddNode("F");
            Node g = graph.AddNode("G");
            Node h = graph.AddNode("H");
            Node i = graph.AddNode("I");
            Node j = graph.AddNode("J");
            
            Node k = graph.AddNode("K");
            Node l = graph.AddNode("L");
            Node m = graph.AddNode("M");
            Node n = graph.AddNode("N");
            Node o = graph.AddNode("O");
            
            Node p = graph.AddNode("P");
            Node q = graph.AddNode("Q");
            Node r = graph.AddNode("R");
            Node s = graph.AddNode("S");
            Node t = graph.AddNode("T");

            Node z = graph.AddNode("Z");

            Arc ab = graph.AddArc(a, b, true);

            Arc bc = graph.AddArc(b, c, true, 3);
            Arc be = graph.AddArc(b, e, true);

            Arc cd = graph.AddArc(c, d, true, 3);

            Arc dh = graph.AddArc(d, h, true);

            Arc ef = graph.AddArc(e, f, true);

            Arc fg = graph.AddArc(f, g, true);

            Arc gh = graph.AddArc(g, h, true);
            Arc gl = graph.AddArc(g, l, true);

            Arc hi = graph.AddArc(h, i, true);

            Arc ij = graph.AddArc(i, j, true, 2);
            Arc il = graph.AddArc(i, l, true);

            Arc jk = graph.AddArc(j, k, true);

            Arc lm = graph.AddArc(l, m, true);

            Arc mn = graph.AddArc(m, n, true);
            Arc mq = graph.AddArc(m, q, true);

            Arc no = graph.AddArc(n, o, true, 3);

            Arc ok = graph.AddArc(o, k, true);
            Arc op = graph.AddArc(o, p, true);

            Arc pt = graph.AddArc(p, t, true, 2);

            Arc qr = graph.AddArc(q, r, true, 2);

            Arc rs = graph.AddArc(r, s, true);

            Arc st = graph.AddArc(s, t, true);


            Node start = a;
            Node end = t;

            Node start2 = h;
            Node end2 = p;



            Dijkstra dijkstra = new Dijkstra(start, end, graph);
            Console.WriteLine(dijkstra.Run());

            dijkstra = new Dijkstra(start2, end2, graph);
            Console.WriteLine(dijkstra.Run());

            dijkstra = new Dijkstra(start, z, graph);
            Console.WriteLine(dijkstra.Run());



            DFS dfs = new DFS(start, end, graph);
            Console.WriteLine(dfs.Run());

            dfs = new DFS(start2, end2, graph);
            Console.WriteLine(dfs.Run());

            dfs = new DFS(start, z, graph);
            Console.WriteLine(dfs.Run());



            BFS bfs = new BFS(start, end, graph);
            Console.WriteLine(bfs.Run());

            bfs = new BFS(start2, end2, graph);
            Console.WriteLine(bfs.Run());

            bfs = new BFS(start, z, graph);
            Console.WriteLine(bfs.Run());

            Console.ReadLine();
        }
    }
}
